import dlt
from pyspark.sql.types import *
from pyspark.sql.functions import *


############# Flights Data  ####################
@dlt.view (name="trans_flights")
def trans_flights() :
    df = spark.readStream.format("delta")\
                    .load("/Volumes/workspace/bronze/bronze_vol/flights/data/")
    df = df.drop("_rescued_data")\
        .withColumn("modifiedDate", current_timestamp())
    return df

dlt.create_streaming_table("silver_flights_scd2")

dlt.create_auto_cdc_flow(
  target = "silver_flights_scd2",
  source = "trans_flights",
  keys = ["flight_id"],
  sequence_by=col("modifiedDate"),
  stored_as_scd_type = 2
)
